
import com.hdcookbook.grin.Director;
import com.hdcookbook.grin.features.InterpolatedModel;
import com.hdcookbook.grin.features.Translator;

/**
 * A director class for a minimal game.  This just manages moving
 * an image around, via a GRIN translator.
 **/

public class EdSullivan extends Director {

    public EdSullivan() {
    }

}
